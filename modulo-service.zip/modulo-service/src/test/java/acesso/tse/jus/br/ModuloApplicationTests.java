package acesso.tse.jus.br;

//import javax.transaction.Transactional;

//import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

//import acesso.tse.jus.br.entity.Modulo;
//import acesso.tse.jus.br.service.ModuloRestController;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ModuloApplicationTests {
	

}
