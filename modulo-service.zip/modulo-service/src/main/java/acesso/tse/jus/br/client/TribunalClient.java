package acesso.tse.jus.br.client;

public interface TribunalClient {

}
