package acesso.tse.jus.br.impl;

public interface LabelSupport {
	public abstract String getLabel();

}
